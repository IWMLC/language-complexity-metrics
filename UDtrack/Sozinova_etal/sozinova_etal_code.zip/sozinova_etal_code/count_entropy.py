##################################################################################################
# Program for counting entropy on the Universal Dependencies *.conllu files
#
# It counts unigram entropy of the original texts and lemmatized texts
# The program applies a morphological segmentation using Morfessor on the lemmatized texts
# and counts the entropy of the segmented texts as well
#
# Author: Olga Sozinova
##################################################################################################

from argparse import ArgumentParser
import os
import re
import math
import codecs
import morfessor


class EntropyUD:

    # Path to the folder with language folders and files
    path = 'UDtrack'

    # Boolean variable for writing extended result file
    extended_flag = False

    # Output file in ud_template format
    ud_template_file = 'Sozinova.csv'

    ud_template = codecs.open(ud_template_file, 'w', 'utf-8')
    header = 'id,language,SBS_INF,SBS_DER\n'
    ud_template.write(header)

    langs_seq = ['afr', 'ara', 'bul', 'cat', 'ces_cac', 'ces_fictree', 'ces_pdt', 'chu', 'cmn', 'dan', 'deu', 'ell',
                 'eng_edt', 'eng_ewt', 'eng_gum', 'eng_lines', 'eng_partut', 'eus', 'fas', 'fin_ftb', 'fin_tdt',
                 'fra_gsd', 'fra_sequoia', 'got', 'grc_perseus', 'grc_proiel', 'heb', 'hin', 'hrv', 'hun', 'ind',
                 'ita_isdt', 'ita_partut', 'ita_postwita', 'jpn', 'kor_gsd', 'kor_kaist', 'lat_ittb', 'lat_proiel',
                 'lav', 'nld_alpino', 'nld_lassysmall', 'nno', 'nob', 'pol_lfg', 'pol_sz', 'por', 'ron_nonstandard',
                 'ron_rrt', 'rus_gsd', 'rus_syntagrus', 'slk', 'slv', 'spa_ancora', 'spa_gsd', 'srp', 'swe_lines',
                 'swe_talbanken', 'tur', 'uig', 'ukr', 'urd', 'vie']

    # Dictionary for result strings for the ud_template format
    ud_template_dict = {
        'afr': ['Afrikaans'],
        'ara': ['Arabic'],
        'bul': ['Bulgarian'],
        'cat': ['Catalan'],
        'ces_cac': ['Czech'],
        'ces_fictree': ['Czech'],
        'ces_pdt': ['Czech'],
        'chu': ['Old Church Slavonic'],
        'cmn': ['Chinese'],
        'dan': ['Danish'],
        'deu': ['German'],
        'ell': ['Greek'],
        'eng_edt': ['Estonian'],
        'eng_ewt': ['English'],
        'eng_gum': ['English'],
        'eng_lines': ['English'],
        'eng_partut': ['English'],
        'eus': ['Basque'],
        'fas': ['Persian'],
        'fin_ftb': ['Finnish'],
        'fin_tdt': ['Finnish'],
        'fra_gsd': ['French'],
        'fra_sequoia': ['French'],
        'got': ['Gothic'],
        'grc_perseus': ['Ancient Greek'],
        'grc_proiel': ['Ancient Greek'],
        'heb': ['Hebrew'],
        'hin': ['Hindi'],
        'hrv': ['Croatian'],
        'hun': ['Hungarian'],
        'ind': ['Indonesian'],
        'ita_isdt': ['Italian'],
        'ita_partut': ['Italian'],
        'ita_postwita': ['Italian'],
        'jpn': ['Japanese'],
        'kor_gsd': ['Korean'],
        'kor_kaist': ['Korean'],
        'lat_ittb': ['Latin'],
        'lat_proiel': ['Latin'],
        'lav': ['Latvian'],
        'nld_alpino': ['Dutch'],
        'nld_lassysmall': ['Dutch'],
        'nno': ['Norwegian'],
        'nob': ['Norwegian'],
        'pol_lfg': ['Polish'],
        'pol_sz': ['Polish'],
        'por': ['Portuguese'],
        'ron_nonstandard': ['Romanian'],
        'ron_rrt': ['Romanian'],
        'rus_gsd': ['Russian'],
        'rus_syntagrus': ['Russian'],
        'slk': ['Slovak'],
        'slv': ['Slovenian'],
        'spa_ancora': ['Spanish'],
        'spa_gsd': ['Spanish'],
        'srp': ['Serbian'],
        'swe_lines': ['Swedish'],
        'swe_talbanken': ['Swedish'],
        'tur': ['Turkish'],
        'uig': ['Uyghur'],
        'ukr': ['Ukrainian'],
        'urd': ['Urdu'],
        'vie': ['Vietnamese']
    }

    # Regex for finding words and lemmas in the *.conllu files
    find_word = re.compile('^[0-9]+\t(.*?)\t(.*?)\t')

    # Regex for finding the language name
    find_language = re.compile('UD_(.*?)-')

    # Dictionary for storing filenames for each language
    languages = {}

    # Segments a lemmatized text using Morfessor
    @staticmethod
    def morph_segment(fname):
        f_segm = codecs.open(fname[:-7] + '_segmentations.txt', 'w', 'utf-8')

        io = morfessor.MorfessorIO()
        corpus = io.read_corpus_file(fname[:-7] + '_lemmas.txt')

        model = morfessor.baseline.BaselineModel()
        model.load_data(corpus)
        model.train_batch()

        f = codecs.open(fname[:-7] + '_lemmas.txt', 'r', 'utf-8')
        words = f.read().split()

        segm_text = ''

        for word in words:
            segm = model.viterbi_segment(word)
            for morph in segm[0]:
                segm_text += morph + '\n'

        f_segm.write(segm_text[:-1])

    # Reads a *.conllu file, counts frequencies of word types and lemmas,
    # runs the morph_segment() function and counts frequencies of segments,
    # outputs frequency dictionaries for the original, lemmatizes and segmented text
    def count_frequencies(self, fname):
        f_lemmas = codecs.open(fname[:-7] + '_lemmas.txt', 'w', 'utf-8')

        freq_dict_raw = {}
        freq_dict_lemmas = {}
        freq_dict_segms = {}

        f = codecs.open(fname, 'r', 'utf-8')
        for line in f:
            if 'PUNCT' not in line and 'SYM' not in line:
                word = re.search(self.find_word, line)
                if word is not None:
                    raw = word.group(1).lower()
                    if raw not in freq_dict_raw:
                        freq_dict_raw[raw] = 1
                    else:
                        freq_dict_raw[raw] += 1

                    lemma = word.group(2).lower()
                    f_lemmas.write(lemma + '\n')

                    if lemma not in freq_dict_lemmas:
                        freq_dict_lemmas[lemma] = 1
                    else:
                        freq_dict_lemmas[lemma] += 1

        self.morph_segment(fname)
        f_segms = codecs.open(fname[:-7] + '_segmentations.txt', 'r', 'utf-8')
        for segm in f_segms:
            if segm not in freq_dict_segms:
                freq_dict_segms[segm] = 1
            else:
                freq_dict_segms[segm] += 1

        return freq_dict_raw, freq_dict_lemmas, freq_dict_segms

    # Counts unigram entropy, basic formula without smoothing
    # Logarithm base 2
    # Outputs number of tokens, number of word types, number of lemmas,
    # entropies of original, lemmatized and segmented texts
    def unigram_entropy(self, fname, base=2.0):
        freq_dicts = self.count_frequencies(fname)
        freq_dict_raw = freq_dicts[0]
        freq_dict_lemmas = freq_dicts[1]
        freq_dict_segms = freq_dicts[2]

        sum_raw = 0
        for w in freq_dict_raw:
            sum_raw += freq_dict_raw[w]

        sum_segms = 0
        for w in freq_dict_segms:
            sum_segms += freq_dict_segms[w]

        freqs_raw = [freq_dict_raw[w] / sum_raw for w in freq_dict_raw]
        freqs_lemmas = [freq_dict_lemmas[w] / sum_raw for w in freq_dict_lemmas]
        freqs_segms = [freq_dict_segms[w] / sum_segms for w in freq_dict_segms]

        # MLE entropy
        entropy_raw = -sum([pk * math.log(pk) / math.log(base) for pk in freqs_raw])
        entropy_lemmas = -sum([pk * math.log(pk) / math.log(base) for pk in freqs_lemmas])
        entropy_segms = -sum([pk * math.log(pk) / math.log(base) for pk in freqs_segms])

        return sum_raw, len(freq_dict_raw), len(freq_dict_lemmas), \
            round(entropy_raw, 3), round(entropy_lemmas, 3), round(entropy_segms, 3)

    # Fills in a dictionary ud_template_dict for the ud_template.csv file
    def write_ud_template(self, lang, file, res):
        id_dict = {
            'ces_cac': 'Czech-CAC.conllu',
            'ces_fictree': 'Czech-FicTree.conllu',
            'ces_pdt': 'Czech-PDT.conllu',
            'eng_edt': 'Estonian-EDT.conllu',
            'eng_ewt': 'English-EWT.conllu',
            'eng_gum': 'English-GUM.conllu',
            'eng_lines': 'English-LinES.conllu',
            'eng_partut': 'English-ParTUT.conllu',
            'fin_ftb': 'Finnish-FTB.conllu',
            'fin_tdt': 'Finnish-TDT.conllu',
            'fra_gsd': 'French-GSD.conllu',
            'fra_sequoia': 'French-Sequoia.conllu',
            'grc_perseus': 'Ancient_Greek-Perseus.conllu',
            'grc_proiel': 'Ancient_Greek-PROIEL.conllu',
            'ita_isdt': 'Italian-ISDT.conllu',
            'ita_partut': 'Italian-ParTUT.conllu',
            'ita_postwita': 'Italian-PoSTWITA.conllu',
            'kor_gsd': 'Korean-GSD.conllu',
            'kor_kaist': 'Korean-Kaist.conllu',
            'lat_ittb': 'Latin-ITTB.conllu',
            'lat_proiel': 'Latin-PROIEL.conllu',
            'nld_alpino': 'Dutch-Alpino.conllu',
            'nld_lassysmall': 'Dutch-LassySmall.conllu',
            'pol_lfg': 'Polish-LFG.conllu',
            'pol_sz': 'Polish-SZ.conllu',
            'ron_nonstandard': 'Romanian-Nonstandard.conllu',
            'ron_rrt': 'Romanian-RRT.conllu',
            'rus_gsd': 'Russian-GSD.conllu',
            'rus_syntagrus': 'Russian-SynTagRus.conllu',
            'spa_ancora': 'Spanish-AnCora.conllu',
            'spa_gsd': 'Spanish-GSD.conllu',
            'swe_lines': 'Swedish-LinES.conllu',
            'swe_talbanken': 'Swedish-Talbanken.conllu',
            'afr': 'Afrikaans',
            'ara': 'Arabic',
            'bul': 'Bulgarian',
            'cat': 'Catalan',
            'chu': 'Old Church Slavonic',
            'cmn': 'Chinese',
            'dan': 'Danish',
            'deu': 'German',
            'ell': 'Greek',
            'eus': 'Basque',
            'fas': 'Persian',
            'got': 'Gothic',
            'heb': 'Hebrew',
            'hin': 'Hindi',
            'hrv': 'Croatian',
            'hun': 'Hungarian',
            'ind': 'Indonesian',
            'jpn': 'Japanese',
            'lav': 'Latvian',
            'nno': 'Norwegian-Nynorsk.conllu',
            'nob': 'Norwegian-Bokmaal.conllu',
            'por': 'Portuguese',
            'slk': 'Slovak',
            'slv': 'Slovenian',
            'srp': 'Serbian',
            'tur': 'Turkish',
            'uig': 'Uyghur',
            'ukr': 'Ukrainian',
            'urd': 'Urdu',
            'vie': 'Vietnamese'
        }

        lang = lang.replace('_', ' ')

        sbs_inf = str(round(res[3] - res[4], 3))
        sbs_der = str(round(res[4] - res[5], 3))

        for lang_id in id_dict:
            if id_dict.get(lang_id) == file or id_dict.get(lang_id) == lang:
                self.ud_template_dict[lang_id].append(sbs_inf)
                self.ud_template_dict[lang_id].append(sbs_der)

    # Walks through the folder with *.conllu files,
    # calls unigram_entropy() function,
    # writes the results to the *.csv table
    def main(self):
        result = None
		
        # Output extended *.csv table
        if self.extended_flag:
            result = codecs.open('extended_results.csv', 'w', 'utf-8')
            result.write('language,filename,number_tokens,number_types_raw,number_types_lemmas,'
                         'entropy_raw,entropy_lemmas,entropy_segms,difference_raw_lemma,difference_lemma_segms\n')

        # Walk through all *.conllu files and count the measure
        for root, dirs, files in os.walk(self.path):
            for file in files:
                if file.endswith('conllu'):
                    language = re.search(self.find_language, root)
                    if language is not None:
                        lang = language.group(1)

                        print(lang + ' ' + file + ' ' + 'in process')

                        if lang not in self.languages:
                            self.languages[lang] = [file]
                        else:
                            self.languages[lang].append(file)
                        res = self.unigram_entropy(os.path.join(root, file))

                        if self.extended_flag:
                            result_string = lang + ',' + file + ',' + str(res[0]) + ',' + str(res[1]) + \
                                ',' + str(res[2]) + ',' + str(res[3]) + ',' + str(res[4]) + \
                                ',' + str(res[5]) + ',' + str(round(res[3] - res[4], 3)) + \
                                ',' + str(round(res[4] - res[5], 3)) + '\n'
                            result.write(result_string)

                        self.write_ud_template(lang, file, res)

        for lang_id in sorted(self.ud_template_dict.keys()):
            result_string = lang_id + ',' + ','.join(self.ud_template_dict[lang_id]) + '\n'
            self.ud_template.write(result_string)

        self.ud_template.close()
        if self.extended_flag:
            result.close()

        # Uncomment to print the files' lists for each language
        # for key in sorted(self.languages, key=self.languages.get):
        #     print(key, self.languages[key])


if __name__ == "__main__":
    parser = ArgumentParser()
    parser.add_argument("-p", "--path",
                        dest='udtrack_path',
                        default='UDtrack',
                        help="path to the folder UDtrack")
    parser.add_argument("-f", "--file",
                        dest='result_file',
                        default='Sozinova.csv',
                        help="path to the file Sozinova.csv")
    parser.add_argument("-e", "--extended",
                        dest='extended',
                        default=False,
                        help="write extended results.csv file")
    args = parser.parse_args()

    eud = EntropyUD()
    eud.path = args.udtrack_path
    eud.ud_template_file = args.result_file
    eud.extended_flag = args.extended

    eud.main()
